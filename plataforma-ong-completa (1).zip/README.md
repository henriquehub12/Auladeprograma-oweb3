# Plataforma ONG

Projeto completo com HTML5, CSS3 e JS para gerenciamento de ONGs.